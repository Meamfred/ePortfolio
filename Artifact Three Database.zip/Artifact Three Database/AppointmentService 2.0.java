/*********************************************
Program.....: Appointment 2.0
Title.......: AppointmentService.java
Author......: James Reid
Date........: April 13th, 2025
**********************************************/

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class AppointmentService {
 public static MongoDatabase connect() {
    String uri = "mongodb://localhost:27017"; // MongoDB Connection string
    MongoClient mongoClient = MongoClients.create(uri);
    return mongoClient.getDatabase("local"); // Database name
  }
}