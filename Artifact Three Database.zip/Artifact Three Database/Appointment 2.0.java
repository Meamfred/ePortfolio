/*********************************************
Program.....: Appointment 2.0
Title.......: Appointment.java
Author......: James Reid
Date........: April 13th, 2025
**********************************************/

import java.util.Date;

public class Appointment {

  private String ID;
  private Date Date;
  private String desc;

public void create() {
  Document document = new Document()
          .append(ID)
          .append(Date)
          .append(desc);        
  getCollection().insertOne(document);
}

public void read() {
  Document document = getCollection().find().first();
  System.out.println(document.toJson());
}

public void update() {
  getCollection().updateOne(
          eq(ID),
          combine(set(Date)
          , set(desc))
          );
}

public void delete() {
  getCollection().delete(ID);
}

}