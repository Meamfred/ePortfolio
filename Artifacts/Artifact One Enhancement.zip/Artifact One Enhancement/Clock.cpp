/*********************************************
Program.....: 12hr & 24hr Clock
Title.......: Clock.cpp
Author......: James Reid
Date........: March 23rd, 2025
**********************************************/

#include "Clock.h"
#include <string>
#include <iostream>

int hours; // initialize variables for Hours, Minutes and seconds
int minutes;
int seconds;
std::string suffix = "AM";

void setTime(int hrs, int min, int sec) { // Assign variables to their corresponding match from the main class.
	hours = hrs;
	minutes = min;
	seconds = sec;
}

void addHour(quantity) { // Adds number of hours entered by user.
	hours = (hours + quantity);
	if (hours == 24) {
		hours = 0;
	}

}

void addSecond(quantity) { // Adds numbers of hours entered by user.
	seconds = seconds + quantity;
	if (seconds == 60) {
		seconds = 0;
		minutes++;
	}

}

void addMinute(quantity) { // Adds numbers of minutes entered by user.
	minutes = minutes + quantity;
	if (minutes == 60) {
		minutes = 0;
		hours++;
	}

}

std::string pad(int v) {
	return std::to_string(v);
}

std::string getSuffix() {
	if (hours < 12) {
		suffix = "AM"; //AM if it is before noon.
		return suffix;
	}
	else {
		suffix = "PM"; //PM if it is after noon.
		return suffix;
	}
}

std::string get12HourFormat() { // Formats the 12 hour clock.
	if (hours < 12) {
		std::cout << hours << ":" << minutes << ":" << seconds << "AM";
	}
	else {
		hours = hours - 12;
		std::cout << hours << ":" << minutes << ":" << seconds << "PM";
	}
	return "";
}

std::string get24HourFormat() { // Formats the 24 hour clock.
	std::cout << hours << ":" << minutes << ":" << seconds;
	return "";
}
