/*********************************************
Program.....: 12hr & 24hr Clock
Title.......: Main
Author......: James Reid
Date........: March 23rd, 2025
**********************************************/

using namespace std;
#include <iostream>
#include <iomanip>
#include <string>
#include "Clock.h"

void printClocks();
void printMenu();


int main() { // Main

	int hours; // Create Hours variable of type Int.
	int minutes; // Create Minutes variable of type Int.
	int seconds; // Create Seconds variable of type Int.
	int user_input; // Creates a variable for the user menu of type Int.
	int quantity; // Creates a variable for tracking the user's desired quantity.

	cout << "Welcome to the 12hr or 24hr clock. Please enter your desired time.\n"

	cout << "Set Hours: " << endl; // Prompts the user to enter a number for the hours.
	std::cin >> hours; // Assigns user input to hours variable.

	cout << "Set Minutes: " << endl; // Prompts the user to enter a number for the minutes.
	std::cin >> minutes; // Assigns user input to minutes variable.

	cout << "Set Seconds: " << endl; // Prompts the user to enter a number for the seconds.
	std::cin >> seconds; // Assigns user input to seconds variable.

	setTime(hours, minutes, seconds); // Call setTime Method

	do { //loop for user input
		cout << "*********************" << " *" << "*********************" << endl;  // style line
		cout << "*  12 - Hour Clock " << " *" << " *  24 - Hour Clock   " << "*" << endl; // label line
		cout << "*    " << get12HourFormat() << "     * *     " << get24HourFormat() << "       *" << endl; // information line
		cout << "*********************" << " *" << "*********************" << endl; // style line
	//print menu
		cout << "      User Menu      " << endl; // Main Menu
		cout << "*********************" << endl; // style line
		cout << " 1 - Add/minus Hour(s) " << endl; // adds to the hours variable.
		cout << " 2 - Add/minus Minute(s) " << endl; // adds to the minutes variable.
		cout << " 3 - Add/minus Second(s) " << endl; // adds to the seconds variable.
		cout << " 4 - Exit Program " << endl; // ends the program.
		cout << "*********************" << endl; // style line

	//Get user choice
	std::cin >> user_input; // Assigns user input to the user_input variable.

	//handle user choice
	if (user_input == 1) { // Option One
		cout << "Enter number of hour(s) + or - : "
		std::cin >> quantity;
		addHour(quantity); // add to the hours variable on the clock.
	}
	if (user_input == 2) { // Option Two
		cout << "Enter number of minute(s) + or - : "
		std::cin >> quantity;
		addMinute(quantity); // add to the minutes variable on the clock.
	}
	if (user_input == 3) { // Option Three
		cout << "Enter number of second(s) + or - : "
		std::cin >> quantity;
		addSecond(quantity); // add to the seconds variable on the clock.
	}
	if (user_input == 4) { // Option Four
		cout << "Good Bye!"; //print good bye for exit
		break; //exit
	}
	else { // If not a vaild option.
		cout << " Error invalid input!"; //error message for invalid input
	}

	} while (user_input != 4); // While user has not chosen to exit.
	
	return 0;
}